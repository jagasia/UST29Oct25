package com.property.controller;

import com.property.entity.Property;
import com.property.service.PropertyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/properties")
public class PropertyController {

    private final PropertyService propertyService;

    @Autowired
    public PropertyController(PropertyService propertyService) {
        this.propertyService = propertyService;
    }

    @PostMapping
    public Property addBooking(@RequestBody Property property) {
        Property newProperty=propertyService.addProperty(property);
        return newProperty;

    }

    @GetMapping
    public List<Property> getAllBookings() {
       List<Property>propertyList= propertyService.getAllProperties();
       return propertyList;

    }
}
