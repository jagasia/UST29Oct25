package com.property.entity;

import java.util.ArrayList;

import org.springframework.boot.autoconfigure.domain.EntityScan;


public class Property {

    public Property(int id, String address, String description) {
        this.id = id;
        this.address = address;
        this.description = description;
    }

    @Override
    public String toString() {
        return "Property [id=" + id + ", address=" + address + ", description=" + description + "]";
    }

    public Property() {
    }

    private int id;
    private String address;
    private String description;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    // public ArrayList<Property> getProperties() {
    //     return properties;
    // }

    // public void setProperties(ArrayList<Property> properties) {
    //     this.properties = properties;
    // }

    // ArrayList<Property>properties=new ArrayList<>();
}
