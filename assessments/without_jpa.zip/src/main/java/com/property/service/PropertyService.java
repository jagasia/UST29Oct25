package com.property.service;

import com.property.entity.Property;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
public class PropertyService {

    private static int counter = 1;
    private final List<Property> propertyList = new ArrayList<>();

    public Property addProperty(Property property) {
        property.setId(counter++);
        propertyList.add(property);
        return property;

    }

    public List<Property> getAllProperties() {
        return propertyList;

    }

}
