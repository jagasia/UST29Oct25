package com.wecp.onlinegamingapplication.controller;


import com.wecp.onlinegamingapplication.entity.Game;
import com.wecp.onlinegamingapplication.service.GameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/games")
public class GameController {
   @Autowired
    private GameService gameService;

    @PostMapping
    public Game addGame(@RequestBody Game game) {
       // add a game
       return gameService.addGame(game);
    }

    @GetMapping("/{gameId}")
    public Game getGameById(@PathVariable("gameId") Long gameId) {
       // get a game by id
       return gameService.getGameById(gameId);
    }

    @GetMapping
    public List<Game> getAllGames() {
       // get all games
       return gameService.getAllGames();
    }
}