package com.wecp.onlinegamingapplication.repository;


import com.wecp.onlinegamingapplication.entity.Team;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TeamRepository extends JpaRepository<Team,Long> {

    // use jpa repository
}