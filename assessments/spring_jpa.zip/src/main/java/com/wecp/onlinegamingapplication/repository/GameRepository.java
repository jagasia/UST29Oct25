package com.wecp.onlinegamingapplication.repository;

import com.wecp.onlinegamingapplication.entity.Game;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GameRepository extends JpaRepository<Game, Long> {
    // use jpa repository
}