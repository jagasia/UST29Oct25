package com.wecp.onlinegamingapplication.controller;


import com.wecp.onlinegamingapplication.entity.Team;
import com.wecp.onlinegamingapplication.service.TeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/teams")
public class TeamController {

  @Autowired
    private TeamService teamService;

    @PostMapping
    public Team addTeam(@RequestBody Team team) {
      // add a team
      return teamService.addTeam(team);
    }


    @GetMapping("/{teamId}")
    public Team getTeamById(@PathVariable("teamId") Long teamId) {
     // get a team by id
     return teamService.getTeamById(teamId);
    }

    @GetMapping
    public List<Team> getAllTeams() {
        // get all teams
        return teamService.getAllTeams();
    }
}