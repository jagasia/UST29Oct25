package com.wecp.onlinegamingapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineGamingApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineGamingApplication.class, args);
	}

}
