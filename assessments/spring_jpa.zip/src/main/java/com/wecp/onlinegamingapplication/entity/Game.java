package com.wecp.onlinegamingapplication.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
// import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Game {
    // implement entity here
    @Id
    @GeneratedValue
    private Long gameId;
    private String gameName;
    private String genre;

    public Game(){}

    public Game(Long gameId, String gameName, String genre) {
        this.gameId = gameId;
        this.gameName = gameName;
        this.genre = genre;
    }

    public Long getGameId() {
        return gameId;
    }

    public void setGameId(Long gameId) {
        this.gameId = gameId;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }
    
}

/*
 * 
 * 
 * 
 {"gameName":"Tennis","genre":"Game"}

 {"teamName":"Chennai Super Kings","game":{"gameId":"1"}}
 */