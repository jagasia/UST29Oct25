package com.wecp.onlinegamingapplication.service;


import com.wecp.onlinegamingapplication.entity.Team;
import com.wecp.onlinegamingapplication.repository.TeamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeamService {

    @Autowired
    private TeamRepository teamRepository;

    public Team addTeam(Team team) {
        // add a team
       return teamRepository.save(team);
    }

    public Team getTeamById(Long teamId) {
       // get team by id
       return teamRepository.findById(teamId).orElse(null);
    }

    public List<Team> getAllTeams() {
      // get all teams
      return teamRepository.findAll();
    }
}