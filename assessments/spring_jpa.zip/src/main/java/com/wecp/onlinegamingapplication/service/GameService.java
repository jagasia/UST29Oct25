package com.wecp.onlinegamingapplication.service;


import com.wecp.onlinegamingapplication.entity.Game;
import com.wecp.onlinegamingapplication.repository.GameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GameService {

    @Autowired
    private GameRepository gameRepository;

    public Game addGame(Game game) {
      // add a game
      //chekc if game id is already found   NOT IMPLEMENTED
      return gameRepository.save(game);
    }

    public Game getGameById(Long gameId) {
       // get game by id
       return gameRepository.findById(gameId).orElse(null);
    }

    public List<Game> getAllGames() {
    // get all games
      return gameRepository.findAll();
    }
}