package com.wecp.onlinegamingapplication.entity;


import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Team {
    // implement entity here
    @Id
    @GeneratedValue
    private Long teamId;
    private String teamName;
    
    @ManyToOne
    private Game game;

    public Team() {
    }

    public Team(Long teamId, String teamName, Game game) {
        this.teamId = teamId;
        this.teamName = teamName;
        this.game = game;
    }

    public Long getTeamId() {
        return teamId;
    }

    public void setTeamId(Long teamId) {
        this.teamId = teamId;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    
}